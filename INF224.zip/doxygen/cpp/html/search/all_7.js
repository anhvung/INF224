var searchData=
[
  ['inputbuffer_28',['InputBuffer',['../structcppu_1_1_input_buffer.html',1,'cppu']]],
  ['inputseparator_29',['inputSeparator',['../classcppu_1_1_socket_buffer.html#a8b859d44a13a2f2583ab5eb5028743d4',1,'cppu::SocketBuffer']]],
  ['isclosed_30',['isClosed',['../classcppu_1_1_socket.html#a2eeeafa5f475525e1cd8116721723410',1,'cppu::Socket::isClosed()'],['../classcppu_1_1_server_socket.html#a9e64d9443686fcfdce6b2c4386597e3b',1,'cppu::ServerSocket::isClosed()']]]
];
