var searchData=
[
  ['descriptor_8',['descriptor',['../classcppu_1_1_socket.html#a06a8fcd9518e6a3e8b33bb64f7fb9036',1,'cppu::Socket::descriptor()'],['../classcppu_1_1_server_socket.html#a905d85f63fdca46ed5ee44eb00e211d1',1,'cppu::ServerSocket::descriptor()']]]
];
