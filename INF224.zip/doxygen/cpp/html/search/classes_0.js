var searchData=
[
  ['callback_82',['Callback',['../structcppu_1_1_t_c_p_server_1_1_callback.html',1,'cppu::TCPServer']]],
  ['callbackmethod_83',['CallbackMethod',['../structcppu_1_1_t_c_p_server_1_1_callback_method.html',1,'cppu::TCPServer']]]
];
