var searchData=
[
  ['error_9',['error',['../classcppu_1_1_t_c_p_server.html#afc47ca4476d9c75d5ea88f73e2acd6d5',1,'cppu::TCPServer']]],
  ['errors_10',['Errors',['../classcppu_1_1_socket.html#a49ea5cb079bd7ae97ecf7eb30c9d9e5f',1,'cppu::Socket']]]
];
