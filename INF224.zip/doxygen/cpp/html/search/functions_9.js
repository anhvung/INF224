var searchData=
[
  ['newfilm_126',['newFilm',['../class_manipulator.html#a96826275ac3f832174ed84482a181ed3',1,'Manipulator']]],
  ['newgroup_127',['newGroup',['../class_manipulator.html#a4aadf854c0a931f2fea45eef398f7f69',1,'Manipulator']]],
  ['newphoto_128',['newPhoto',['../class_manipulator.html#a0a8b39466c08432b824bf382c69c7b12',1,'Manipulator']]],
  ['newvideo_129',['newVideo',['../class_manipulator.html#af4033aa0f40823b6a905251c70bd887b',1,'Manipulator']]]
];
