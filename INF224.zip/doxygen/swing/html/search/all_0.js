var searchData=
[
  ['client_0',['Client',['../class_client.html',1,'Client'],['../class_client.html#a163113b9c3fda23dcdc750db9278afbe',1,'Client.Client()']]]
];
