
**Anh-Vu Nguyen**
**INF224**


4) Une fonction virtuelle pure doit avoir un comportement implémenté pour les classes qui héritent, au rique d'avoir un problème à la compilation.

on met un =0 pour quelle soit pure un plus du virtual

5) On utilise le polymorphisme, les méthodes doivent être virtuelles en c++, les tableaux contiennents des pointeurs.

7) il faut modifier des desctructeur  de la classe film pour éviter les fuites mémoires
La copie peut poser des problèmes de pointage : on utilise des copies profondes

Questions traités : toutes sauf les étapes 12 et 13 optionnelles




